import 'package:flutter/material.dart';
import 'package:digital_bus_pass_system/login_screen.dart';
import 'package:digital_bus_pass_system/register_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});


  @override
  Widget build(BuildContext context) {
    print('rebuild');
    return MaterialApp(
      title:'Bus App',
      theme: ThemeData(
        primarySwatch:Colors.blue,

      ),
      debugShowCheckedModeBanner: false,
      home:LoginScreen(),



      // Scaffold(
      //     backgroundColor: Colors.white,
      //
      //     body: SafeArea(
      //       child: Column(
      //           children: [
      //             SizedBox(height:50,),
      //         Row(
      //           mainAxisAlignment: MainAxisAlignment.center,
      //           crossAxisAlignment: CrossAxisAlignment.center,
      //           children:const[
      //             Image(
      //               height:100,
      //               width:100,
      //               image:AssetImage('assets/pmpml bus.png' ,),
      //             ),
      //             SizedBox(width:5,),
      //             Text('Bus',
      //                 style: TextStyle(
      //                   fontSize: 24,
      //                   fontFamily : 'Rubik Medium',
      //                   color: Color(0xff203142)
      //                 ))
      //
      //           ]
      //         ),
      //         const Center(
      //           child: Text('Login',
      //               style: TextStyle(
      //                   fontSize: 26,
      //                   fontFamily: 'Rubik Medium',
      //                   color: Color(0xff203142))
      //           ),
      //         ),
      //         const SizedBox(height : 11),
      //         const Center(
      //           child: Text('Welcome to Digital \nPMPML App',
      //               textAlign: TextAlign.center,
      //               style: TextStyle(
      //                   fontSize:16,
      //                   fontFamily: 'Rubik Regular',
      //                   color: Color(0xff4C5980))
      //           ),
      //         ),
      //          SizedBox(height:25,),
      //          Padding(
      //            padding: EdgeInsets.only(left: 20, right:20, top:10,),
      //            child: TextFormField(
      //              decoration: InputDecoration(
      //                hintText:'Email',
      //                fillColor:const Color(0xffF8F9FA),
      //                filled: true,
      //                 prefixIcon: const Icon(Icons.alternate_email, color:Color(0xff323F4B),),
      //                  focusedBorder : OutlineInputBorder(
      //                  borderSide: const BorderSide(color:Color(0xffE4E7EB)),
      //                  borderRadius: BorderRadius.circular(10),
      //                ),
      //                  enabledBorder : OutlineInputBorder(
      //                    borderSide: const BorderSide(color:Color(0xffE4E7EB)),
      //                    borderRadius: BorderRadius.circular(10),
      //                  ),
      //              )
      //            ),
      //          ),
      //
      //             SizedBox(height: 20,),
      //
      //             Padding(
      //               padding: EdgeInsets.only(left: 20, right:20, top:10,),
      //               child: TextFormField(
      //                   decoration: InputDecoration(
      //                       hintText:'Password',
      //                       fillColor:const Color(0xffF8F9FA),
      //                       filled: true,
      //
      //                       prefixIcon: const Icon(Icons.lock_open, color:Color(0xff323F4B),),
      //                       suffixIcon: Icon(Icons.visibility_off_outlined),
      //                       focusedBorder : OutlineInputBorder(
      //                         borderSide: const BorderSide(color:Color(0xffE4E7EB)),
      //                         borderRadius: BorderRadius.circular(10),
      //                       ),
      //                       enabledBorder : OutlineInputBorder(
      //                       borderSide: const BorderSide(color:Color(0xffE4E7EB)),
      //                       borderRadius: BorderRadius.circular(10),
      //             ),
      //
      //                   ),
      //               ),
      //             ),
      //
      //             Padding(
      //               padding: const EdgeInsets.only(right:16,),
      //               child: Row(
      //                 mainAxisAlignment: MainAxisAlignment.end,
      //
      //                 children: [
      //                   Text('Forgot Password?',
      //                       style: TextStyle(
      //                           fontSize: 14,
      //                           fontFamily : 'Rubik Regular',
      //                           color: Color(0xff203142),
      //                           decoration:TextDecoration.underline,
      //                       ),),
      //                 ],
      //               ),
      //             ),
      //
      //          const SizedBox(height:100, ),
      //
      //          Container(
      //            height:50,
      //            width:300,
      //            decoration:BoxDecoration(
      //              color: Color(0xff2E7D32),
      //              borderRadius: BorderRadius.circular(10),
      //            ),
      //            child:const Center(
      //              child: Text('Log In',
      //                  style: TextStyle(
      //                      fontSize: 30,
      //                      fontFamily : 'Rubik Medium',
      //                      color: Colors.white,
      //                  )),
      //            ),
      //          )  ,
      //             SizedBox(height:20,),
      //             Row(
      //               mainAxisAlignment: MainAxisAlignment.center,
      //               children:const[
      //                 Text("Don't have an Account?",
      //                     textAlign: TextAlign.center,
      //                     style: TextStyle(
      //                         fontSize:16,
      //                         fontFamily: 'Rubik Regular',
      //                         color: Color(0xff4C5980))
      //                 ),
      //
      //                 Text('Sign Up',
      //                     textAlign: TextAlign.center,
      //                     style: TextStyle(
      //                         fontSize:16,
      //                         fontFamily: 'Rubik Medium',
      //                         color: Color(0xff2E7D32)),
      //                 )
      //               ]
      //             )
      //       ] ),
      //     )),
    );
  }
}
