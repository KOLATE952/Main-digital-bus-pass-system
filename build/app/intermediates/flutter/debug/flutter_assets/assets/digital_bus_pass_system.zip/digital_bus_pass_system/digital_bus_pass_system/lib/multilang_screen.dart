import 'package:flutter/material.dart';
import 'package:digital_bus_pass_system/homepage.dart';
// Import HomePage

class MultilangScreen extends StatefulWidget {
  const MultilangScreen({Key? key}) : super(key: key);

  @override
  _MultilangScreenState createState() => _MultilangScreenState();
}

class _MultilangScreenState extends State<MultilangScreen> {
  final List<Map<String, dynamic>> _languages = [
    {'name': 'English', 'isSelected': false},
    {'name': 'Hindi', 'isSelected': false},
    {'name': 'Spanish', 'isSelected': false},
    {'name': 'French', 'isSelected': false},
    {'name': 'German', 'isSelected': false},
    {'name': 'Chinese', 'isSelected': false},
    {'name': 'Japanese', 'isSelected': false},
    {'name': 'Arabic', 'isSelected': false},
  ];

  void _proceed() {
    final selectedLanguages = _languages
        .where((language) => language['isSelected'])
        .map((language) => language['name'])
        .toList();

    if (selectedLanguages.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please select at least one language to proceed.'),
          duration: Duration(seconds: 2),
        ),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => HomePage(), // Navigate to HomePage
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Select Your Languages"),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blueAccent, Colors.lightBlueAccent],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Text(
                    "Select Your Languages",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                      ),
                      itemCount: _languages.length,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              _languages[index]['isSelected'] =
                              !_languages[index]['isSelected'];
                            });
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: _languages[index]['isSelected']
                                  ? Colors.white
                                  : Colors.blue[50],
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black12,
                                  blurRadius: 5,
                                  offset: Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Checkbox(
                                  value: _languages[index]['isSelected'],
                                  onChanged: (bool? value) {
                                    setState(() {
                                      _languages[index]['isSelected'] = value!;
                                    });
                                  },
                                ),
                                Text(
                                  _languages[index]['name'],
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: _languages[index]['isSelected']
                                        ? Colors.blueAccent
                                        : Colors.black87,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _proceed,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                    padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: Text(
                    'Proceed to Home',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
                SizedBox(height: 20),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
