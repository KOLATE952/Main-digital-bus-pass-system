package com.example.digital_bus_pass_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
