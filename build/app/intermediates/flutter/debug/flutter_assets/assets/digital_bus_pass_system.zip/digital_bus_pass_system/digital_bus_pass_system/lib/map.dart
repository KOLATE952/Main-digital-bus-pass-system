import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  Completer<GoogleMapController> _controller = Completer();

  // Define initial map location (center of the map)
  static const LatLng _initialPosition = LatLng(19.0760, 72.8777); // Example: Mumbai
  late LatLng _startLocation; // Start bus stop location
  late LatLng _endLocation; // End bus stop location

  // Markers list
  Set<Marker> _markers = {};

  @override
  void initState() {
    super.initState();
    fetchBusStopLocations(); // Fetch the start and end locations from the backend
  }

  // Function to fetch bus stop locations from the backend
  Future<void> fetchBusStopLocations() async {
    final url = Uri.parse('https://your-backend-api.com/bus-stops'); // Replace with your API
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        // Assuming the API returns start and end coordinates as:
        // { "start": { "lat": 19.0760, "lng": 72.8777 }, "end": { "lat": 18.5204, "lng": 73.8567 } }
        setState(() {
          _startLocation = LatLng(data['start']['lat'], data['start']['lng']);
          _endLocation = LatLng(data['end']['lat'], data['end']['lng']);

          _markers.add(Marker(
            markerId: MarkerId('start'),
            position: _startLocation,
            infoWindow: InfoWindow(title: "Start Bus Stop"),
          ));

          _markers.add(Marker(
            markerId: MarkerId('end'),
            position: _endLocation,
            infoWindow: InfoWindow(title: "End Bus Stop"),
          ));
        });
      } else {
        throw Exception("Failed to load locations");
      }
    } catch (error) {
      print("Error fetching locations: $error");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Bus Route Map"),
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: _initialPosition,
          zoom: 12,
        ),
        markers: _markers,
        onMapCreated: (GoogleMapController controller) {
          _controller.complete(controller);
        },
      ),
    );
  }
}
