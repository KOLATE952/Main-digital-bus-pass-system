dependencies:
google_maps_flutter: ^2.2.0 # Ensure the version is compatible
